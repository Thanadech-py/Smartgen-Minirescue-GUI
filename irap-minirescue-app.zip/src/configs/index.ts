import Config from "../configs/compose/Config";

const configs = Config

export default configs