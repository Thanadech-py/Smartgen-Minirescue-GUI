export default {
    ROSMasterURL : {
        url : "ws://10.42.2.150:9090/",
    }
}
